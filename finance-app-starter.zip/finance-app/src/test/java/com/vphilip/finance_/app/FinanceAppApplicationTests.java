package com.vphilip.finance_.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
